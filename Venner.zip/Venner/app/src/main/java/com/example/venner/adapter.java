package com.example.venner;

import android.widget.Adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;


public class adapter extends FragmentStateAdapter {
    public adapter(@NonNull FragmentManager fragmentManager, Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0: return new Fragment_OnGoing();
            case 1: return new Fragment_Past();
        }
        return new Fragment_OnGoing();
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
